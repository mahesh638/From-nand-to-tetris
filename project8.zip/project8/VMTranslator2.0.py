#import fileinput
#import sys
#print("\n")
#print(sys.argv[1])
#addr=str(sys.argv[1])


#marv=addr.replace(".vm",".asm")



#line=[]
#for f in fileinput.input():
 #   print(f)
  #  line.append(f)
line=[]
import glob
path="C:/nand2tetris/projects/08/FunctionCalls/StaticsTest/*vm"
files=glob.glob(path)
for name in files:
    if(name=="C:/nand2tetris/projects/08/FunctionCalls/StaticsTest\Sys.vm"):
        with open(name) as f:
            for x in f:
                line.append(x)
for name in files:
    if(name!="C:/nand2tetris/projects/08/FunctionCalls/StaticsTest\Sys.vm"):
        with open(name) as f:
            for x in f:
                line.append(x)

lines=[]
maincount=0
code=[]
for x in line:
    x=x.strip()
    if x:
        lines.append(x)
for x in lines:
    if(x.startswith("//")==False):
        code.append(x)
for x in code:
    print(x)
eq=0
lt=0
gt=0
p=3
temp=5
static=16
asm=[]
call=0
fstack=[]
rstack=[]
nostack=[]
for x in code:
    asm.append("\n//" + x +"\n\n")
    if(x.startswith("push constant")):
        X=x.rsplit(' ')[2]
        asm.append('@'+X)
        asm.append("D=A")
        asm.append("@SP")
        asm.append("A=M")
        asm.append("M=D")
        asm.append("@SP")
        asm.append("M=M+1")

    elif(x.startswith("push temp")):
       X=x.rsplit(' ')[2]
       temp1=temp+int(X)
       asm.append("@"+str(temp1))
       asm.append("D=M")
       asm.append("@SP")
       asm.append("A=M")
       asm.append("M=D")
       asm.append("@SP")
       asm.append("M=M+1")

    elif(x.startswith("push static")):
       X=x.rsplit(' ')[2]
       temp1=static+int(X)
       asm.append("@"+str(temp1))
       asm.append("D=M")
       asm.append("@SP")
       asm.append("A=M")
       asm.append("M=D")
       asm.append("@SP")
       asm.append("M=M+1")
       
       

    elif(x.startswith("push local")):
        X=x.rsplit(' ')[2]
        asm.append("@LCL")
        asm.append("A=M")
        X=int(X)
        for i in range (0,X,1):
            asm.append("A=A+1")
        asm.append("D=M")
        asm.append("@SP")
        asm.append("A=M")
        asm.append("M=D")
        asm.append("@SP")
        asm.append("M=M+1")

    elif(x.startswith("push that")):
        X=x.rsplit(' ')[2]
        asm.append("@THAT")
        asm.append("A=M")
        X=int(X)
        for i in range (0,X,1):
            asm.append("A=A+1")
        asm.append("D=M")
        asm.append("@SP")
        asm.append("A=M")
        asm.append("M=D")
        asm.append("@SP")
        asm.append("M=M+1")

    elif(x.startswith("push this")):
        X=x.rsplit(' ')[2]
        asm.append("@THIS")
        asm.append("A=M")
        X=int(X)
        for i in range (0,X,1):
            asm.append("A=A+1")
        asm.append("D=M")
        asm.append("@SP")
        asm.append("A=M")
        asm.append("M=D")
        asm.append("@SP")
        asm.append("M=M+1")

    elif(x.startswith("push argument")):
        X=x.rsplit(' ')[2]
        asm.append("@ARG")
        X=int(X)
        asm.append("A=M")
        for i in range (0,X,1):
            asm.append("A=A+1")
        asm.append("D=M")
        asm.append("@SP")
        asm.append("A=M")
        asm.append("M=D")
        asm.append("@SP")
        asm.append("M=M+1")

    elif(x.startswith("push pointer")):
        X=x.rsplit(' ')[2]
        p1=p+int(X)
        asm.append("@"+str(p1))
        asm.append("D=M")
        asm.append("@SP")
        asm.append("A=M")
        asm.append("M=D")
        asm.append("@SP")
        asm.append("M=M+1")
        

    elif(x.startswith("pop local")):
        X=x.rsplit(' ')[2]
        asm.append("@SP")
        asm.append("A=M-1")
        asm.append("D=M")
        asm.append("@LCL")
        asm.append("A=M")
        X=int(X)
        for i in range (0,X,1):
            asm.append("A=A+1")
        asm.append("M=D")
        asm.append("@SP")
        asm.append("M=M-1")

    elif(x.startswith("pop temp")):
       X=x.rsplit(' ')[2]
       temp1=temp+int(X)
       asm.append("@SP")
       asm.append("A=M-1")
       asm.append("D=M")
       asm.append("@"+str(temp1))
       asm.append("M=D")
       asm.append("@SP")
       asm.append("M=M-1")

    elif(x.startswith("pop static")):
       X=x.rsplit(' ')[2]
       temp1=static+int(X)
       asm.append("@SP")
       asm.append("A=M-1")
       asm.append("D=M")
       asm.append("@"+str(temp1))
       asm.append("M=D")
       asm.append("@SP")
       asm.append("M=M-1")
       
       

    elif(x.startswith("pop argument")):
        X=x.rsplit(' ')[2]
        asm.append("@SP")
        asm.append("A=M-1")
        asm.append("D=M")
        asm.append("@ARG")
        asm.append("A=M")
        X=int(X)
        for i in range (0,X,1):
            asm.append("A=A+1")
        asm.append("M=D")
        asm.append("@SP")
        asm.append("M=M-1")

    elif(x.startswith("pop that")):
        X=x.rsplit(' ')[2]
        asm.append("@SP")
        asm.append("A=M-1")
        asm.append("D=M")
        asm.append("@THAT")
        asm.append("A=M")
        X=int(X)
        for i in range (0,X,1):
            asm.append("A=A+1")
        asm.append("M=D")
        asm.append("@SP")
        asm.append("M=M-1")

    elif(x.startswith("pop this")):
        X=x.rsplit(' ')[2]
        asm.append("@SP")
        asm.append("A=M-1")
        asm.append("D=M")
        asm.append("@THIS")
        asm.append("A=M")
        X=int(X)
        for i in range (0,X,1):
            asm.append("A=A+1")
        asm.append("M=D")
        asm.append("@SP")
        asm.append("M=M-1")

    elif(x.startswith("pop pointer")):
        X=x.rsplit(' ')[2]
        p1=p+int(X)
        asm.append("@SP")
        asm.append("A=M-1")
        asm.append("D=M")
        asm.append("@"+str(p1))
        asm.append("M=D")
        asm.append("@SP")
        asm.append("M=M-1")
        

         
    elif(x.startswith("add")):
        asm.append("@SP")
        asm.append("A=M-1")
        asm.append("D=M")
        asm.append("A=A-1")
        asm.append("D=D+M")
        asm.append("M=D")
        asm.append("@SP")
        asm.append("M=M-1")
        

    elif(x.startswith("sub")):
        asm.append("@SP")
        asm.append("A=M-1")
        asm.append("D=M")
        asm.append("A=A-1")
        asm.append("D=D-M")
        asm.append("D=-D")
        asm.append("M=D")
        asm.append("@SP")
        asm.append("M=M-1")
    
        

    elif(x.startswith("lt")):
        asm.append("@SP")
        asm.append("A=M-1")
        asm.append("D=M")
        asm.append("A=A-1")
        asm.append("D=D-M")
        asm.append("@Nopelt"+str(lt))
        asm.append("D;JLE")
        asm.append("@SP")
        asm.append("A=M-1")
        asm.append("A=A-1")
        asm.append("M=-1")
        asm.append("@endlt"+str(lt))
        asm.append("0;JMP")
        asm.append("(Nopelt"+str(lt)+")")
        asm.append("@SP")
        asm.append("A=M-1")
        asm.append("A=A-1")
        asm.append("M=0")
        asm.append("(endlt"+str(lt)+")")
        asm.append("@SP")
        asm.append("M=M-1")
        lt=lt+1
        

    elif(x.startswith("gt")):
        asm.append("@SP")
        asm.append("A=M-1")
        asm.append("D=M")
        asm.append("A=A-1")
        asm.append("D=D-M")
        asm.append("@Nopegt"+str(gt))
        asm.append("D;JGE")
        asm.append("@SP")
        asm.append("A=M-1")
        asm.append("A=A-1")
        asm.append("M=-1")
        asm.append("@endgt"+str(gt))
        asm.append("0;JMP")
        asm.append("(Nopegt"+str(gt)+")")
        asm.append("@SP")
        asm.append("A=M-1")
        asm.append("A=A-1")
        asm.append("M=0")
        asm.append("(endgt"+str(gt)+")")
        asm.append("@SP")
        asm.append("M=M-1")
        gt=gt+1
        

    elif(x.startswith("eq")):
        asm.append("@SP")
        asm.append("A=M-1")
        asm.append("D=M")
        asm.append("A=A-1")
        asm.append("D=D-M")
        asm.append("@Nopeeq"+str(eq))
        asm.append("D;JNE")
        asm.append("@SP")
        asm.append("A=M-1")
        asm.append("A=A-1")
        asm.append("M=-1")
        asm.append("@endeq"+str(eq))
        asm.append("0;JMP")
        asm.append("(Nopeeq"+str(eq)+")")
        asm.append("@SP")
        asm.append("A=M-1")
        asm.append("A=A-1")
        asm.append("M=0")
        asm.append("(endeq"+str(eq)+")")
        asm.append("@SP")
        asm.append("M=M-1")
        eq=eq+1
        
    elif(x.startswith("neg")):
        asm.append("@SP")
        asm.append("A=M-1")
        asm.append("M=-M")

    elif(x.startswith("not")):
        asm.append("@SP")
        asm.append("A=M-1")
        asm.append("D=M+1")
        asm.append("M=-D")
        
    elif(x.startswith("and")):
        asm.append("@SP")
        asm.append("A=M-1")
        asm.append("D=M")
        asm.append("A=A-1")
        asm.append("M=M&D")
        asm.append("@SP")
        asm.append("M=M-1")

    elif(x.startswith("or")):
        asm.append("@SP")
        asm.append("A=M-1")
        asm.append("D=M")
        asm.append("A=A-1")
        asm.append("M=M|D")
        asm.append("@SP")
        asm.append("M=M-1")

    elif(x.startswith("label")):
        X=x.rsplit(' ')[1]
        asm.append('('+X+')')

    elif(x.startswith("if-goto")):
        X=x.rsplit(' ')[1]
        asm.append("@SP")
        asm.append("A=M-1")
        asm.append("D=M")
        asm.append("@SP")
        asm.append("M=M-1")
        asm.append("@"+X)
        asm.append("D;JGT")

    elif(x.startswith("goto")):
        X=x.rsplit(' ')[1]
        asm.append("@"+X)
        asm.append("0;JMP")

    elif(x.startswith("call")):
        X=x.rsplit(' ')[2]
        Y=x.rsplit(' ')[1]
        X=int(X)
        
    

        asm.append("@1")
        asm.append("D=M")
        asm.append("@SP")
        asm.append("A=M")
        asm.append("A=A+1")
        asm.append("M=D")

        asm.append("@2")
        asm.append("D=M")
        asm.append("@SP")
        asm.append("A=M")
        asm.append("A=A+1")
        asm.append("A=A+1")
        asm.append("M=D")

        asm.append("@3")
        asm.append("D=M")
        asm.append("@SP")
        asm.append("A=M")
        asm.append("A=A+1")
        asm.append("A=A+1")
        asm.append("A=A+1")
        asm.append("M=D")

        asm.append("@4")
        asm.append("D=M")
        asm.append("@SP")
        asm.append("A=M")
        asm.append("A=A+1")
        asm.append("A=A+1")
        asm.append("A=A+1")
        asm.append("A=A+1")
        asm.append("M=D")

        asm.append("@SP")
        asm.append("D=M")
        for i in range(0,X):
            asm.append("D=D-1")
        asm.append("@ARG")
        asm.append("M=D")

        
        call=call+1
        callstr=str(call)
        asm.append("@"+Y+"$ret."+callstr)
        asm.append("D=A")
        asm.append("@SP")
        asm.append("A=M")
        asm.append("M=D")
        
        

        asm.append("@SP")
        asm.append("M=M+1")
        asm.append("M=M+1")
        asm.append("M=M+1")
        asm.append("M=M+1")
        asm.append("M=M+1")

        asm.append("@SP")
        asm.append("D=M")
        asm.append("@LCL")
        asm.append("M=D")

        asm.append("@"+Y)
        asm.append("0;JMP")

        asm.append("("+Y+"$ret."+callstr+")")
        
    

        

    elif(x.startswith("function Sys.init")):
        X=x.rsplit(' ')[2]
        Y=x.rsplit(' ')[1]
        X=int(X)
        fstack.append(Y)
        asm.append("@LCL")
        asm.append("A=M")
        for i in range (0,X):
            asm.append("M=0")
            asm.append("A=A+1")
        asm.append("@SP")
        for i in range(0,X):
            asm.append("M=M+1")

    elif(x.startswith("function")):
        X=x.rsplit(' ')[2]
        Y=x.rsplit(' ')[1]
        fstack.append(Y)
        X=int(X)
        asm.append("("+Y+")")
        asm.append("@LCL")
        asm.append("A=M")
        for i in range (0,X):
            asm.append("M=0")
            asm.append("A=A+1")
        asm.append("@SP")
        for i in range(0,X):
            asm.append("M=M+1")
        if("main" in x):
            maincount=maincount+1

    elif(x.startswith("return")):
        asm.append("@SP")
        asm.append("A=M")
        asm.append("A=A-1")
        asm.append("D=M")
        asm.append("@ARG")
        asm.append("A=M")
        asm.append("M=D")

        
        
        if(maincount==0):
            asm.append("@ARG")
            asm.append("D=M")
            asm.append("@SP")
            asm.append("M=D+1")
        else:
            asm.append("@ARG")
            asm.append("D=M")
            asm.append("@SP")
            asm.append("M=D")
            maincount=0
        
        asm.append("@LCL")
        asm.append("A=M")
        asm.append("A=A-1")
        asm.append("D=M")
        asm.append("@4")
        asm.append("M=D")
        
        asm.append("@LCL")
        asm.append("A=M")
        asm.append("A=A-1")
        asm.append("A=A-1")
        asm.append("D=M")
        asm.append("@3")
        asm.append("M=D")
        
        asm.append("@LCL")
        asm.append("A=M")
        asm.append("A=A-1")
        asm.append("A=A-1")
        asm.append("A=A-1")
        asm.append("D=M")
        asm.append("@2")
        asm.append("M=D")

        asm.append("@LCL")
        asm.append("A=M")
        asm.append("A=A-1")
        asm.append("A=A-1")
        asm.append("A=A-1")
        asm.append("A=A-1")
        asm.append("A=A-1")
        asm.append("D=M")
        asm.append("@6")
        asm.append("M=D")

        
        
        asm.append("@LCL")
        asm.append("A=M")
        asm.append("A=A-1")
        asm.append("A=A-1")
        asm.append("A=A-1")
        asm.append("A=A-1")
        asm.append("D=M")
        asm.append("@1")
        asm.append("M=D")

        

        asm.append("@6")
        asm.append("A=M")
        asm.append("0;JMP")
        
        
        
        
        
        
with open("C:/nand2tetris/projects/08/FunctionCalls/StaticsTest/StaticsTest.asm", "w") as F:
    for item in asm:
        F.write("%s\n" %item)
